# Image Forgery Detection

This Project consists of both Frontend and Backend code and code is user-friendly.

Image forgery detection is emerging as one of the hot research topics in the area of image forensics. In this modern digital era due to availability of advanced technology, powerful computer photo editing tools and software packages digital images can be easily forged. In the fields such as forensics, medical imaging, industrial photography and e-commerce authenticating the originality of images and detecting traces of manipulation without any prior knowledge of the image content or any embedded information is a challenging task and quite impossible to say images are authentic. As a result, photographs have almost lost their trustworthiness. We are trying to build a model that can detect these manipulations in images and help us identify forged images.


Everything is in the zip file, so just download the project and keep learning !!!
